from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import json

import pandas as pd

from .models import Run, RunSet
from .jsonfix import try_repair_json


# Columns expected from firmware contract :contentReference[oaicite:1]{index=1}
EXPECTED_COLS = [
    "timestamp_ms",
    "ax_mps2", "ay_mps2", "az_mps2",
    "mag_mps2",
    "vib_inst_mps2",
    "vib_rms_mps2",
    "vib_net_mps2",
    "thr_cmd",
    "esc_us",
    "rpm",
]


@dataclass
class LoadOptions:
@dataclass
class LoadOptions:
    add_time_s: bool = True
    add_g_units: bool = True
    sort_by_time: bool = True

    # JSON is now strict by default
    tolerate_bad_json: bool = False

    drop_unknown_cols: bool = False
    load_summaries: bool = True

    # Parquet cache
    write_parquet_cache: bool = True
    overwrite_parquet: bool = False

    # Sampling rate detection
    detect_fs: bool = True
    fs_quantile: float = 0.5        # median dt
    fs_min_samples: int = 20

def _detect_fs_hz_from_timestamp_ms(df: pd.DataFrame, q: float, min_samples: int) -> Optional[float]:
    if "timestamp_ms" not in df.columns:
        return None

    ts = pd.to_numeric(df["timestamp_ms"], errors="coerce").dropna().values
    if len(ts) < (min_samples + 1):
        return None

    # Ensure sorted before diff
    ts = pd.Series(ts).sort_values().values
    dt_ms = pd.Series(ts).diff().dropna()

    # Remove zero/negative or insane deltas
    dt_ms = dt_ms[(dt_ms > 0) & (dt_ms < 10_000)]
    if len(dt_ms) < min_samples:
        return None

    dt_ms_q = float(dt_ms.quantile(q))
    if dt_ms_q <= 0:
        return None

    return 1000.0 / dt_ms_q


def _parse_run_id(stem: str) -> Optional[int]:
    s = stem.upper()
    if not s.startswith("RUN"):
        return None
    digits = s[3:]
    if not digits.isdigit():
        return None
    return int(digits)


def _read_json(path: Path) -> Dict:
    return json.loads(path.read_text(encoding="utf-8", errors="strict"))


def _postprocess(df: pd.DataFrame, opt: LoadOptions, issues: List[str]) -> pd.DataFrame:
    if opt.drop_unknown_cols:
        keep = [c for c in df.columns if c in EXPECTED_COLS]
        df = df[keep].copy()

    # numeric coercion for known signals (missing cols are fine)
    numeric_cols = [
        "timestamp_ms", "thr_cmd", "esc_us", "rpm",
        "ax_mps2", "ay_mps2", "az_mps2", "mag_mps2",
        "vib_inst_mps2", "vib_rms_mps2", "vib_net_mps2",
    ]
    for c in numeric_cols:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")

    if opt.add_time_s and "timestamp_ms" in df.columns:
        df["time_s"] = df["timestamp_ms"] / 1000.0

    if opt.sort_by_time and "timestamp_ms" in df.columns:
        df = df.sort_values("timestamp_ms").reset_index(drop=True)

    # Units: some labels say “g” but values are m/s² :contentReference[oaicite:2]{index=2}
    if opt.add_g_units:
        g = 9.80665
        for c in [
            "ax_mps2", "ay_mps2", "az_mps2", "mag_mps2",
            "vib_inst_mps2", "vib_rms_mps2", "vib_net_mps2",
        ]:
            if c in df.columns:
                df[c.replace("_mps2", "_g")] = df[c] / g

    if "rpm" not in df.columns or df["rpm"].isna().all():
        issues.append("rpm_missing_or_empty")

    return df


def load_run(csv_path: Path, opt: Optional[LoadOptions] = None) -> Run:
    opt = opt or LoadOptions()
    csv_path = Path(csv_path)

    run_id = _parse_run_id(csv_path.stem)
    if run_id is None:
        raise ValueError(f"Not a RUN#### CSV: {csv_path.name}")

    pq_path = _parquet_path_for(csv_path)
    if pq_path.exists():
        df = pd.read_parquet(pq_path)
    else:
        df = pd.read_csv(csv_path)

    json_path = csv_path.with_suffix(".JSON")
    meta: Dict = {}
    issues: List[str] = []

if json_path.exists():
    meta = _read_json(json_path)
else:
    json_path = None
    issues.append("json_missing")

    df = _postprocess(df, opt, issues)
        run = Run(
        run_id=run_id,
        csv_path=csv_path,
        json_path=json_path,
        df=df,
        meta=meta,
        issues=issues,
    )

    # Derived sampling rate (for FFT correctness)
    if opt.detect_fs:
        fs = _detect_fs_hz_from_timestamp_ms(df, q=opt.fs_quantile, min_samples=opt.fs_min_samples)
        if fs is not None:
            meta.setdefault("derived", {})
            meta["derived"]["fs_hz"] = fs
            meta["derived"]["dt_ms_est"] = 1000.0 / fs
        else:
            issues.append("fs_detect_failed")

    if opt.write_parquet_cache:
        try:
            _write_run_cache(run, overwrite=opt.overwrite_parquet)
        except Exception as e:
            run.issues.append(f"parquet_cache_failed:{e}")

    return run


def _read_summary_csv(path: Path) -> Optional[pd.DataFrame]:
    if not path.exists():
        return None
    df = pd.read_csv(path)
    # light cleanup: strip whitespace column headers
    df.columns = [c.strip() for c in df.columns]
    return df

def _parquet_path_for(csv_path: Path) -> Path:
    return csv_path.with_suffix(".parquet")

def _meta_cache_path_for(csv_path: Path) -> Path:
    # separate from the firmware JSON sidecar
    return csv_path.with_suffix(".meta.json")

def _write_run_cache(run: Run, overwrite: bool) -> None:
    pq = _parquet_path_for(run.csv_path)
    mj = _meta_cache_path_for(run.csv_path)

    if pq.exists() and not overwrite:
        return

    # Data
    run.df.to_parquet(pq, index=False)

    # Metadata (already repaired/parsed in-memory if present)
    if run.meta:
        mj.write_text(json.dumps(run.meta, indent=2), encoding="utf-8")


def load_folder(folder: Path, opt: Optional[LoadOptions] = None) -> RunSet:
    folder = Path(folder)
    opt = opt or LoadOptions()

    rs = RunSet(folder=folder)

    # runs
    csv_files = sorted(folder.glob("RUN*.CSV"))
    for csv_path in csv_files:
        try:
            rs.runs.append(load_run(csv_path, opt))
        except Exception as e:
            rs.issues.append(f"failed_load:{csv_path.name}:{e}")

    # summaries
    if opt.load_summaries:
        rs.summary = _read_summary_csv(folder / "RUN_SUMMARY.CSV")
        if rs.summary is None:
            rs.issues.append("summary_missing:RUN_SUMMARY.CSV")

        rs.summary_short = _read_summary_csv(folder / "RUN_SUMMARY_SHORT.CSV")
        if rs.summary_short is None:
            rs.issues.append("summary_missing:RUN_SUMMARY_SHORT.CSV")

    return rs
