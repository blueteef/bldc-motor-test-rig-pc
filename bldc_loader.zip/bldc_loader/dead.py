import sys
from pathlib import Path

sys.path.append(str(Path(__file__).parent))

from bldc_loader import load_folder

rs = load_folder(Path(r"C:\Users\snyder\Documents\Motor Logs\SD_dump"))

print("Total runs:", len(rs.runs))

for r in rs.runs[:5]:
    print(r.name, r.meta.get("derived", {}).get("fs_hz"), r.issues)
